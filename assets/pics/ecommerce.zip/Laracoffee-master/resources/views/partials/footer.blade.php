<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-center small">
            Copyright &copy; Laracoffee
            <?= date('Y'); ?>
        </div>
    </div>
</footer>