@extends('Admin.layout.app')
@section('admin_content')
    <div class="row">
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <span class="text-muted fs-lg"><i class="mdi mdi-dots-vertical align-middle"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a class="dropdown-item" href="#">Today</a>
                            <a class="dropdown-item" href="#">Last Week</a>
                            <a class="dropdown-item" href="#">Last Month</a>
                            <a class="dropdown-item" href="#">Current Year</a>
                        </div>
                    </div>
                    <p class="fs-md text-muted mb-0">Total Sessions</p>

                    <div class="row mt-4 align-items-end">
                        <div class="col-lg-6">
                            <h3 class="mb-4"><span class="counter-value" data-target="368.24">0</span>k </h3>
                            <p class="text-success mb-0"><i class="bi bi-arrow-up me-1"></i> 06.41% Last Month</p>
                        </div>
                        <div class="col-lg-6">
                            <div id="session_chart" data-colors='["--tb-primary", "--tb-secondary"]'
                                class="apex-charts m-n3 mt-n4" dir="ltr"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end col-->
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <span class="text-muted fs-lg"><i class="mdi mdi-dots-vertical align-middle"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a class="dropdown-item" href="#">Today</a>
                            <a class="dropdown-item" href="#">Last Week</a>
                            <a class="dropdown-item" href="#">Last Month</a>
                            <a class="dropdown-item" href="#">Current Year</a>
                        </div>
                    </div>
                    <p class="fs-md text-muted mb-0">Avg. Visit Duration</p>

                    <div class="row mt-4 align-items-end">
                        <div class="col-lg-6">
                            <h3 class="mb-4"><span class="counter-value" data-target="01.47">0</span>sec </h3>
                            <p class="text-success mb-0"><i class="bi bi-arrow-up me-1"></i> 13% Last Month</p>
                        </div>
                        <div class="col-lg-6">
                            <div id="visti_duration_chart" data-colors='["--tb-primary", "--tb-secondary"]'
                                class="apex-charts m-n3 mt-n4" dir="ltr"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end col-->
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <span class="text-muted fs-lg"><i class="mdi mdi-dots-vertical align-middle"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a class="dropdown-item" href="#">Today</a>
                            <a class="dropdown-item" href="#">Last Week</a>
                            <a class="dropdown-item" href="#">Last Month</a>
                            <a class="dropdown-item" href="#">Current Year</a>
                        </div>
                    </div>
                    <p class="fs-md text-muted mb-0">Impressions</p>

                    <div class="row mt-4 align-items-end">
                        <div class="col-lg-6">
                            <h3 class="mb-4"><span class="counter-value" data-target="1647">0</span></h3>
                            <p class="text-danger mb-0"><i class="bi bi-arrow-down me-1"></i> 07.26% Last Week</p>
                        </div>
                        <div class="col-lg-6">
                            <div id="impressions_chart" data-colors='["--tb-secondary"]' class="apex-charts m-n3 mt-n4"
                                dir="ltr"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end col-->
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="dropdown float-end">
                        <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <span class="text-muted fs-lg"><i class="mdi mdi-dots-vertical align-middle"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a class="dropdown-item" href="#">Today</a>
                            <a class="dropdown-item" href="#">Last Week</a>
                            <a class="dropdown-item" href="#">Last Month</a>
                            <a class="dropdown-item" href="#">Current Year</a>
                        </div>
                    </div>
                    <p class="fs-md text-muted mb-0">Total Views</p>

                    <div class="row mt-4 align-items-end">
                        <div class="col-lg-6">
                            <h3 class="mb-4"><span class="counter-value" data-target="291.32">0</span>k </h3>
                            <p class="text-success mb-0"><i class="bi bi-arrow-up me-1"></i> 13% Last Month</p>
                        </div>
                        <div class="col-lg-6">
                            <div id="views_chart" data-colors='["--tb-primary"]' class="apex-charts m-n3 mt-n4"
                                dir="ltr"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end col-->
    </div><!--end row-->
@endsection
