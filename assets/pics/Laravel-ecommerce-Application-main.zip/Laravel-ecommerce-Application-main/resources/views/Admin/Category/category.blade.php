@extends('Admin.layout.app')
@section('admin_content')
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h4 class="card-title mb-0">Category</h4>
                    <button class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#myModal">Add Category</button>
                </div><!-- end card header -->

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table align-middle table-nowrap mb-0">
                            <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($categories as $category)
                                    <tr>
                                        <th scope="row">{{ $loop->iteration }}</th>
                                        <td>{{ $category->name }}</td>
                                        <td>
                                            <button href="{{ route('category.edit', ['category' => $category]) }}"
                                                class="btn btn-warning btn-sm">
                                                <i class="bi bi-pencil-square"></i>
                                            </button>
                                            @extends('Admin.layout.app')
                                            @section('admin_content')
                                                <div class="row">
                                                    <div class="col-xl-12">
                                                        <div class="card">
                                                            <div class="card-header d-flex justify-content-between">
                                                                <h4 class="card-title mb-0">Category</h4>
                                                                <button class="btn btn-dark" data-bs-toggle="modal"
                                                                    data-bs-target="#myModal">Add Category</button>
                                                            </div><!-- end card header -->

                                                            <div class="card-body">
                                                                <div class="table-responsive">
                                                                    <table class="table align-middle table-nowrap mb-0">
                                                                        <thead>
                                                                            <tr>
                                                                                <th scope="col">ID</th>
                                                                                <th scope="col">Name</th>
                                                                                <th scope="col">Action</th>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            @foreach ($categories as $category)
                                                                                <tr>
                                                                                    <th scope="row">{{ $loop->iteration }}
                                                                                    </th>
                                                                                    <td>{{ $category->name }}</td>
                                                                                    <td>
                                                                                        <button
                                                                                            href="{{ route('category.edit', ['category' => $category]) }}"
                                                                                            class="btn btn-warning btn-sm">
                                                                                            <i class="bi bi-pencil-square"></i>
                                                                                        </button>
                                                                                        <form
                                                                                            action="{{ route('category.destroy', ['category' => $category]) }}"
                                                                                            method="post"
                                                                                            style="display: inline;">
                                                                                            @csrf
                                                                                            @method('DELETE')
                                                                                            <button type="submit"
                                                                                                class="btn btn-danger btn-sm">
                                                                                                <i class="bi bi-trash"></i>
                                                                                            </button>
                                                                                        </form>

                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach
                                                                        </tbody>
                                                                    </table>
                                                                </div>

                                                            </div><!-- end card-body -->

                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="myModal" class="modal fade" tabindex="-1"
                                                    aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="myModalLabel">Add Category</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                    aria-label="Close"></button>
                                                            </div>
                                                            <form action="{{ route('category.store') }}" method="post">
                                                                @csrf
                                                                <div class="modal-body">
                                                                    <div class="mb-2">
                                                                        <label for="" class="form-label">Category
                                                                            Name</label>
                                                                        <input type="text" name="category_name"
                                                                            class="form-control" placeholder="e.g Mens">
                                                                        @error('catergory_name')
                                                                            <p class="text-danger my-1">{{ $message }}</p>
                                                                        @enderror
                                                                    </div>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-light"
                                                                        data-bs-dismiss="modal">Close</button>
                                                                    <button type="submit" class="btn btn-dark ">Add
                                                                        Category</button>
                                                                </div>
                                                            </form>

                                                        </div><!-- /.modal-content -->
                                                    </div><!-- /.modal-dialog -->
                                                </div><!-- /.modal -->
                                            @endsection

                                        </td>
                                    </tr>
                                @endforeach


                            </tbody>
                        </table>
                    </div>

                </div><!-- end card-body -->

            </div>
        </div>
    </div>
    <div id="myModal" class="modal fade" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true"
        style="display: none;">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Add Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="{{ route('category.store') }}" method="post">
                    @csrf
                    <div class="modal-body">
                        <div class="mb-2">
                            <label for="" class="form-label">Category Name</label>
                            <input type="text" name="category_name" class="form-control" placeholder="e.g Mens">
                            @error('catergory_name')
                                <p class="text-danger my-1">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark ">Add Category</button>
                    </div>
                </form>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <script>
        
    </script>
@endsection
