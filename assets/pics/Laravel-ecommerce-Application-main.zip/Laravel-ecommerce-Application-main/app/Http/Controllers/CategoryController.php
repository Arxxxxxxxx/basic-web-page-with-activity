<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = Category::OrderByDesc('id')->get();
        return view("Admin.Category.category", compact('categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'category_name' => 'required'
        ]);
        $category = Category::create([
            'name' => $request->category_name
        ]);
        if ($category) {
            return redirect()->route('category.index')->with('success', 'category created successfully');
        }
        return redirect()->route('category.index')->with('error', 'category not created ! ');


    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category $category)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {

        $category_ = $category->delete();

        if ($category_) {
            return redirect()->route('category.index')->with('success', 'category deleted successfully');
        }
        return redirect()->route('category.index')->with('error', 'category deleted successfully');
    }

}
